/**
 * TypeScript declarations for <xoip-call> Custom Element.
 * @version 2.0.0
 */

// ─── Signaling ────────────────────────────────────────────────────────────────

export type SignalType = 'offer' | 'answer' | 'ice-candidate';
export type RoomState = 'waiting' | 'active' | 'ended';

export interface SignalData {
  type: SignalType;
  payload: RTCSessionDescriptionInit | RTCIceCandidateInit;
  from?: string;
}

export declare abstract class SignalingAdapter extends EventTarget {
  roomId: string | null;
  role: 'polite' | 'impolite';
  connect(): Promise<void>;
  disconnect(): Promise<void>;
  createRoom(): Promise<string>;
  joinRoom(roomId: string): Promise<void>;
  endRoom(): Promise<void>;
  sendSignal(signal: SignalData): Promise<void>;
  onSignal(callback: (signal: SignalData) => void): void;
  onRoomState(callback: (state: RoomState) => void): void;
  generateRoomId(): string;
}

export declare class FirebaseSignalingAdapter extends SignalingAdapter {
  constructor(firebaseApp: object, options?: { collection?: string });
}

export declare class WebSocketSignalingAdapter extends SignalingAdapter {
  constructor(url: string, options?: { autoReconnect?: boolean; reconnectDelay?: number });
}

export declare class NostrSignalingAdapter extends SignalingAdapter {
  constructor(options?: { relays?: string[]; privateKeyHex?: string });
}

// ─── Core ─────────────────────────────────────────────────────────────────────

export interface WebRTCEngineOptions {
  polite: boolean;
  iceServers?: RTCIceServer[];
  onSignal: (signal: SignalData) => void;
  onRemoteTrack: (event: RTCTrackEvent) => void;
  onDataMessage: (data: unknown) => void;
  onConnectionState: (state: RTCPeerConnectionState) => void;
  onError: (error: Error) => void;
}

export declare class WebRTCEngine {
  polite: boolean;
  pc: RTCPeerConnection | null;
  dataChannel: RTCDataChannel | null;
  constructor(options: WebRTCEngineOptions);
  init(): RTCPeerConnection;
  close(): void;
  setupDataChannel(): void;
  addAudioTrack(track: MediaStreamTrack, stream?: MediaStream): RTCRtpSender;
  addVideoTrack(track: MediaStreamTrack, stream?: MediaStream): RTCRtpSender;
  replaceTrack(kind: 'audio' | 'video', newTrack: MediaStreamTrack | null): Promise<void>;
  setTransceiverDirection(kind: 'audio' | 'video', direction: RTCRtpTransceiverDirection): void;
  handleSignal(signal: SignalData): Promise<void>;
  sendData(data: object | string): void;
}

export interface MediaManagerOptions {
  multiCamera?: boolean;
  videoConstraints?: MediaTrackConstraints;
  audioConstraints?: MediaTrackConstraints;
  onError?: (error: Error) => void;
}

export declare class MediaManager {
  primaryStream: MediaStream | null;
  secondaryStreams: MediaStream[];
  screenStream: MediaStream | null;
  readonly isScreenSharing: boolean;
  constructor(options?: MediaManagerOptions);
  start(): Promise<{ audioTrack: MediaStreamTrack; videoTracks: MediaStreamTrack[] }>;
  startScreenShare(onReplace?: (track: MediaStreamTrack | null) => void): Promise<MediaStreamTrack>;
  stopScreenShare(onReplace?: (track: MediaStreamTrack | null) => void): Promise<MediaStreamTrack | null>;
  switchCamera(deviceId: string): Promise<MediaStreamTrack>;
  switchMicrophone(deviceId: string): Promise<MediaStreamTrack>;
  setAudioMute(muted: boolean): void;
  setVideoMute(muted: boolean): void;
  getDevices(): Promise<{ cameras: MediaDeviceInfo[]; microphones: MediaDeviceInfo[]; speakers: MediaDeviceInfo[] }>;
  stopAll(): void;
}

export interface NetworkQuality {
  rtt: number | null;
  packetLoss: number | null;
  bitrateOut: number;
  bitrateIn: number;
  connectionType: 'P2P' | 'STUN' | 'TURN' | 'unknown';
  quality: 'excellent' | 'good' | 'poor' | 'bad' | 'unknown';
}

export declare class StatsMonitor {
  constructor(pc: RTCPeerConnection, options: { intervalMs?: number; onQuality: (q: NetworkQuality) => void });
  start(): void;
  stop(): void;
  getFullReport(): Promise<RTCStatsReport>;
}

// ─── E2EE ─────────────────────────────────────────────────────────────────────

export declare class E2EEManager {
  constructor(options: { onSendPublicKey: (key: string) => void; onError?: (e: Error) => void });
  initialize(): Promise<void>;
  receiveRemotePublicKey(pubKeyBase64: string): Promise<void>;
  attachToPeerConnection(pc: RTCPeerConnection, workerUrl: string): Promise<void>;
  terminate(): void;
}

// ─── Main Element ─────────────────────────────────────────────────────────────

export interface XoipCallEventMap {
  'room-created':        CustomEvent<{ roomId: string }>;
  'room-joined':         CustomEvent<{ roomId: string }>;
  'remote-stream-ready': CustomEvent<{ stream: MediaStream; track: MediaStreamTrack }>;
  'screen-share-started':CustomEvent<{}>;
  'screen-share-stopped':CustomEvent<{}>;
  'channel-message':     CustomEvent<{ data: unknown }>;
  'network-quality':     CustomEvent<NetworkQuality>;
  'speaking-start':      CustomEvent<{ source: 'local' | 'remote' }>;
  'speaking-stop':       CustomEvent<{ source: 'local' | 'remote' }>;
  'call-ended':          CustomEvent<{ reason: 'local_hangup' | 'remote_hangup' | 'failed' }>;
  'use-custom-video':    CustomEvent<{ element: Element }>;
  'switch-remote-stream':CustomEvent<{ stream: MediaStream }>;
  'error':               CustomEvent<{ code: string; message: string; error: Error }>;
}

export declare function compressConfig(config: object): Promise<string>;
export declare function decompressConfig(token: string): Promise<Record<string, any>>;

export declare class XoipCallElement extends HTMLElement {
  // Статические методы для токенизации конфига
  static compressConfig(config: object): Promise<string>;
  static decompressConfig(token: string): Promise<Record<string, any>>;

  // Свойства
  signalingAdapter: SignalingAdapter | null;
  readonly localStream: MediaStream | null;
  readonly remoteStreams: Map<string, MediaStream>;

  // Управление сессией
  createRoom(): Promise<string | undefined>;
  joinRoom(roomId: string): Promise<void>;
  leaveRoom(): Promise<void>;

  // Управление медиа и устройствами
  setAudioMute(muted: boolean): void;
  setVideoMute(muted: boolean): void;
  startScreenShare(): Promise<void>;
  stopScreenShare(): Promise<void>;
  switchCamera(deviceId: string): Promise<void>;
  getDevices(): Promise<{ cameras: MediaDeviceInfo[]; microphones: MediaDeviceInfo[]; speakers: MediaDeviceInfo[] }>;
  enterPiP(): Promise<void>;
  exitPiP(): Promise<void>;
  setAudioOnlyMode(enabled: boolean): void;

  // Данные и телеметрия
  sendData(data: unknown): void;
  getStats(): Promise<RTCStatsReport | null>;

  addEventListener<K extends keyof XoipCallEventMap>(
    type: K, listener: (this: XoipCallElement, ev: XoipCallEventMap[K]) => void, options?: boolean | AddEventListenerOptions
  ): void;
  removeEventListener<K extends keyof XoipCallEventMap>(
    type: K, listener: (this: XoipCallElement, ev: XoipCallEventMap[K]) => void, options?: boolean | EventListenerOptions
  ): void;
}

// ─── Global HTMLElement augmentation ─────────────────────────────────────────

declare global {
  interface HTMLElementTagNameMap {
    'xoip-call': XoipCallElement;
  }
}
