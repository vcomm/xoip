/**
 * TypeScript declarations for <xoip-qos> Web Component & QoS SDK.
 * @package @vcomm/xoip-qos
 * @version 1.0.0
 */

export interface QoSAssistantOptions {
  decisionEngineEnabled?: boolean;
  monitorInbound?: boolean;
  controlChannel?: RTCDataChannel | null;
}

export interface XoipQoSOptions {
  decisionEngineEnabled?: boolean;
  monitorInbound?: boolean;
  autoStart?: boolean;
}

export interface OpenDashboardOptions {
  newTab?: boolean;
}

/**
 * Web Component <xoip-qos>
 * Declarative QoS management component for WebRTC calls.
 */
export declare class XoipQoSElement extends HTMLElement {
  static readonly observedAttributes: string[];

  for: string;
  monitorInbound: boolean;
  decisionEngine: boolean;
  autoStart: boolean;
  target: HTMLElement | null;
  readonly adapter: XoipQoSAdapter | null;
  readonly isActive: boolean;

  connectedCallback(): void;
  disconnectedCallback(): void;
  attributeChangedCallback(name: string, oldValue: string | null, newValue: string | null): void;

  start(): void;
  stop(): void;
  openDashboard(urlOrEvent?: string | MouseEvent, options?: OpenDashboardOptions): void;
}

/**
 * Adapter connecting WebRTC QoS monitoring to <xoip-call> or custom WebRTC host elements.
 */
export declare class XoipQoSAdapter extends EventTarget {
  readonly element: HTMLElement;
  readonly peerConnection: RTCPeerConnection | null;
  readonly controlChannel: RTCDataChannel | null;
  readonly assistant: WebRTCQoSAssists | null;

  constructor(xoipElement: HTMLElement, options?: XoipQoSOptions);

  start(): void;
  stop(): void;
  setDecisionEngine(enabled: boolean): void;
  isActive(): boolean;
  openDashboard(urlOrEvent?: string | MouseEvent, options?: OpenDashboardOptions): void;
  destroy(): void;
}

/**
 * Core WebRTC QoS Assistant: metric tick loop, Web Workers orchestrator.
 */
export declare class WebRTCQoSAssists {
  readonly pc: RTCPeerConnection;
  readonly sessionId: string;
  readonly monitorInbound: boolean;
  decisionEngineEnabled: boolean;

  constructor(pc: RTCPeerConnection, sessionId: string, options?: QoSAssistantOptions);

  start(): void;
  stop(): void;
  setDecisionEngine(enabled: boolean): void;
  isDecisionEngineEnabled(): boolean;
  isActive(): boolean;
  applyRemoteBitrateRequest(cmd: { action: string; targetKbps: number; reason?: string }): void;
}

/**
 * BroadcastChannel-based Event Bus between Main thread and Workers.
 */
export declare class WorkerEventBus {
  constructor(options?: { sourceName?: string; allowedTopics?: string[] });
  publish(topic: string, payload: any, options?: any): boolean;
  subscribe(topic: string, handler: (msg: any) => void): () => void;
  close(): void;
}

export declare const QOS_CHANNEL_NAME: string;
export declare const QOS_DB_NAME: string;
export declare const QOS_STORE_NAME: string;
export declare const QOS_DB_VERSION: number;

export declare function openQoSExperienceDB(): Promise<IDBDatabase>;
export declare function saveQoSExperience(entry: {
  sessionId: string;
  timestamp?: number;
  stats?: any;
  action?: any;
  reward?: number;
}): Promise<void>;
export declare function exportQoSExperience(sessionId: string): Promise<any[]>;

declare global {
  interface HTMLElementTagNameMap {
    'xoip-qos': XoipQoSElement;
  }
}
