# @webrtc/qos — Bidirectional WebRTC QoS SDK v2.0

Standalone, framework-agnostic QoS monitoring for `RTCPeerConnection`.  
Zero dependencies on any application framework (no multicall, no Vite).

## Features

- **Bidirectional monitoring** — Outbound (upload) + Inbound (download) streams
- **4 Web Workers** — qos, ai, ice, history; communicate via `WorkerEventBus` (BroadcastChannel)
- **Adaptive bitrate** — local encoder control via `RTCPeerConnection.setParameters()`
- **Remote peer control** — `DataChannel` commands to ask remote to reduce/increase bitrate
- **Live dashboard** — `dashboard/index.html` with Upload / Download tab switcher (Chart.js CDN)
- **Web Component `<xoip-qos>`** — Declarative HTML association via `for="id"` (Zero modifications to `<xoip-call>`)
- **Variant B adapter** — `XoipQoSAdapter` for programmatic integration

## Structure

```
qos/
├── index.js                  # SDK entry: exports WebRTCQoSAssists, XoipQoSAdapter, XoipQoSElement
├── src/
│   ├── xoip-qos.js           # Web Component <xoip-qos> (Variant 1: for="id")
│   ├── XoipQoSAdapter.js     # Variant B: external adapter for <xoip-call>
│   ├── webrtc-qos.js         # Core: tick loop, stats serialization, worker management
│   ├── WorkerEventBus.js     # Isomorphic BroadcastChannel-based event bus
│   ├── qos-experience-db.js  # IndexedDB persistence helpers
│   ├── config.js             # QOS_CHANNEL_NAME constant
│   └── workers/
│       ├── qos-worker.js     # Outbound + Inbound sliding-window metrics
│       ├── ai-worker.js      # MOS scoring, bitrate policy, remote commands
│       ├── ice-worker.js     # ICE candidate path monitoring
│       └── history-worker.js # IndexedDB persistence
└── dashboard/
    └── index.html            # Standalone dashboard (no build step)
```

## Quick Start 1 — Web Component `<xoip-qos>` (Declarative `for="id"`)

```html
<script type="module" src="/qos/index.js"></script>

<!-- Target call element -->
<xoip-call id="my-call" call-id="room_42"></xoip-call>

<!-- Declarative QoS controller -->
<xoip-qos for="my-call" monitor-inbound decision-engine auto-start></xoip-qos>

<button onclick="document.querySelector('xoip-qos').openDashboard()">Open Dashboard</button>
```

### Supported Attributes & Properties of `<xoip-qos>`:
- `for`: ID of the target element in the DOM (resolves resiliently even if `<xoip-call>` renders after `<xoip-qos>`).
- `monitor-inbound`: Enable/disable incoming streams analysis (`true` by default).
- `decision-engine`: Enable/disable adaptive AI bitrate regulation (`true` by default).
- `auto-start`: Automatically start when target fires `connectionstatechange: connected` (`true` by default).
- `.target`: Direct JS setter/getter for element instance (`qosEl.target = xoipCall`).
- `.adapter`: Reference to the active `XoipQoSAdapter`.
- `.start()`, `.stop()`, `.openDashboard(url?)`.

## Quick Start 2 — Programmatic Adapter (Variant B)

```html
<xoip-call id="call" call-id="room_42"></xoip-call>

<script type="module">
  import { XoipQoSAdapter } from '/qos/index.js';

  const xoip = document.getElementById('call');
  const qos  = new XoipQoSAdapter(xoip, {
    monitorInbound: true,
    decisionEngineEnabled: true,
  });

  document.getElementById('qosBtn').onclick =
    () => qos.openDashboard('/qos/dashboard/');

  window.addEventListener('beforeunload', () => qos.destroy());
</script>
```

## Minimal contract from `<xoip-call>`

```js
get peerConnection()  → RTCPeerConnection | null
get controlChannel()  → RTCDataChannel | null   // optional
// dispatches: CustomEvent('connectionstatechange', { detail: { state: 'connected'|'disconnected'|... } })
```

## Changelog

### v2.0.0
- Added Web Component `<xoip-qos>` (`src/xoip-qos.js`) with `for="id"` association.
- Added `inbound-rtp` monitoring (video + audio) in `webrtc-qos.js`
- Added `processInboundStats()` + `getInboundWindowStats()` in `qos-worker.js`
- Added `qos.inbound.degraded` event + `decideRemoteAction()` in `ai-worker.js`
- Added `ai.remote.bitrate.request` → DataChannel delivery in `webrtc-qos.js`
- Added `applyRemoteBitrateRequest()` public method
- Added `XoipQoSAdapter` — Variant B external plugin
- Dashboard: Upload/Download tab switcher, 4 inbound charts, remote request indicator
